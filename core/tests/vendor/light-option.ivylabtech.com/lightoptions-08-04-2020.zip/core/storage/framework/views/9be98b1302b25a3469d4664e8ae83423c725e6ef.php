

<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('body'); ?>


    <h2 class="mb-4">Dashboard</h2>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="d-flex border">
                <div class="customs_bd text-light p-4">
                    <div class="d-flex align-items-center h-100">
                        <span style="font-size: 35px; width: 55px;">
                             <i class="fas fa-utensils"></i>
                         </span>
                    </div>
                </div>
                <div class="flex-grow-1 bg-white p-4">
                    <a href="<?php echo e(route('admin.foodCategory.index')); ?>" style="text-decoration: none;"><p class="text-uppercase text-secondary mb-0"> Total food Category </p></a>
                    <h3 class="font-weight-bold mb-0"><?php echo e(count($foodCategories)); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="d-flex border">
                <div class="customs_bd text-light p-4">
                    <div class="d-flex align-items-center h-100">

                         <span style="font-size: 35px; width: 55px;">
                             <i class="fas fa-utensils"></i>
                         </span>
                    </div>
                </div>
                <div class="flex-grow-1 bg-white p-4">
                    <a href="<?php echo e(route('admin.foods.index')); ?>" style="text-decoration: none;"><p class="text-uppercase text-secondary mb-0"> TOTAL Food </p></a>
                    <h3 class="font-weight-bold mb-0"><?php echo e(count($foodItems)); ?> </h3>
                </div>
            </div>
        </div>

    </div>



    
    <h2 class="mb-4">Order Statistics</h2>
    <div class="card mb-4">
        <div class="card-header bg-white font-weight-bold">
            Order Statistics By Graph
        </div>
        <div class="card-body">
            <div id="order" style="height: 250px;"></div>

        </div>
    </div>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
             var months = <?php echo json_encode(array_values(month_arr()));  ?>;
            new Morris.Line({
                element: 'order',
                data: <?php echo $order; ?>,
                xkey: 'month',
                ykeys: [ 'PendingOrder','CompleteOrder'],
                labels: ['Pending','Complete'],

                xLabelFormat: function(x) { // <--- x.getMonth() returns valid index
                    var month = months[x.getMonth()];
                    return month;
                },
                dateFormat: function(x) {
                    var month = months[new Date(x).getMonth()];
                    return month;
                },
            });
        });
    </script>

    <!-- morris css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/morris.css')); ?>">
    <script src=" <?php echo e(asset('assets/admin/js/raphael-min.js')); ?>"></script>
    <script src=" <?php echo e(asset('assets/admin/js/morris.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/hasaanmalik/light-option.ivylabtech.com/core/resources/views/admin/pages/dashboard.blade.php ENDPATH**/ ?>