<?php $__env->startSection('title', 'Admin | Social settings'); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-fluid">
        <h2 class="mb-4">Social settings</h2>
        <div class="row ">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-white font-weight-bold">
                        Social icon list
                        <a href=""
                           class="btn btn-primary btn-md float-right customs_btn" data-toggle="modal"
                           data-target="#createsocial">
                            <i class="fa fa-plus"></i> ADD NEW
                        </a>
                    </div>
                    <div class="card-body ">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Icon</th>
                                <th scope="col">Link</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>


                            <?php $__currentLoopData = $socialSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($social->name); ?></td>
                                    <td><i class="<?php echo e($social->icon); ?>"></i></td>
                                    <td><?php echo e($social->link); ?></td>

                                    <td class=" actions">
                                        <button type="submit" class="btn btn-info font-weight-bold"
                                                data-name="<?php echo e($social->name); ?>"
                                                data-icon="<?php echo e($social->icon); ?>"
                                                data-link="<?php echo e($social->link); ?>"
                                                data-id="<?php echo e($social->id); ?>"
                                                data-toggle="modal" data-target="#socialedit">
                                            <i class="fa fa-edit"></i> Edit
                                        </button>

                                        <button type="submit" class="btn btn-danger font-weight-bold"
                                                data-id="<?php echo e($social->id); ?>"
                                                data-toggle="modal" data-target="#socialDelete"><i class="fa fa-trash"></i>
                                            Delete
                                        </button>
                                        
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>



    
    <div class="modal modal-danger fade" id="socialDelete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center">Confirmation Message</h4>
                </div>
                <form action="<?php echo e(!empty($social->id) ? route('admin.social.delete','delete') : '#'); ?>"
                      method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input class="form-control form-control-lg mb-3" type="hidden" name="id" id="id">
                        <h4 class="text-center">Are you sure ?</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Yes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <div class="modal modal-danger fade" id="createsocial" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center" id="myModalLabel">Create social icon</h4>
                </div>
                <form action="<?php echo e(route('admin.social.create')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">

                        <div class="col-md-12 ">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Name</strong></label>
                                <input class="form-control form-control-lg mb-3" type="text" name="name" required>
                            </div>
                        </div>

                        <div class="col-md-12 ">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Icon</strong></label>
                                <input class="form-control form-control-lg mb-3" type="text" name="icon"
                                       placeholder="fas fa-home" required>
                                <small class="text-info">For code visit : https://fontawesome.com/icons</small>

                            </div>
                        </div>

                        <div class="col-md-12 ">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Link</strong></label>
                                <input class="form-control form-control-lg mb-3" type="text" name="link" required>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    
    <div class="modal modal-danger fade" id="socialedit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center" id="myModalLabel">Create social icon</h4>
                </div>
                <form action="<?php echo e(route('admin.social.update')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <input class="form-control" type="hidden" name="id" id="socialId">

                    <div class="modal-body">

                        <div class="col-md-12 ">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Name</strong></label>
                                <input class="form-control form-control-lg mb-3" type="text" name="name" id="name" required>
                            </div>
                        </div>

                        <div class="col-md-12 ">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Icon</strong></label>
                                <input class="form-control form-control-lg mb-3" type="text" name="icon" id="icon"
                                       placeholder="fas fa-home" required>
                                <small class="text-info">For code visit : https://fontawesome.com/icons</small>

                            </div>
                        </div>

                        <div class="col-md-12 ">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Link</strong></label>
                                <input class="form-control form-control-lg mb-3" type="text" name="link" id="link" required>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->startSection('scripts'); ?>

    
    <script>
        $('#socialedit').on('show.bs.modal', function (event) {

            var button = $(event.relatedTarget);

            var name = button.data('name');
            var icon = button.data('icon');
            var link = button.data('link');
            var socialId = button.data('id');

            var modal = $(this);

            modal.find('#name').val(name);
            modal.find('#icon').val(icon);
            modal.find('#link').val(link);
            modal.find('#socialId').val(socialId);

        })
    </script>

    
    <script>
        $('#socialDelete').on('show.bs.modal', function (event) {

            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this)
            modal.find('.modal-body #id').val(id);
        })
    </script>
<?php $__env->stopSection(); ?>


<script>
    $('#frontEndSetting li:nth-child(6)').addClass('active');
    $('#frontEndSetting').addClass('show');
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lightoption\core\resources\views/admin/frontendsetting/socialSettings.blade.php ENDPATH**/ ?>