
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/fullcalendar.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/bootadmin.min.css')); ?>">

    
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('assets/admin/js/jquery-2.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-toggle.min.js')); ?>"></script>

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/customs.css')); ?>">

    
    <link href="<?php echo e(asset('assets/admin/css/toastr.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(asset('assets/admin/js/toastr.js')); ?>"></script>

    <!--Icofont CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/icofont.css')); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body class="bg-light">


 <?php echo $__env->make('admin.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="d-flex">
       
       <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="content p-4">

            
            <script>
                <?php if(Session()->has('success')): ?>

toastr.success("<?php echo e(Session('success')); ?>")
                <?php endif; ?>

                <?php if(Session()->has('warning')): ?>

toastr.warning("<?php echo e(Session('warning')); ?>")
                <?php endif; ?>

              <?php if(Session()->has('errors')): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
toastr.error("<?php echo e($error); ?>")
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </script>

            <?php echo $__env->yieldContent('body'); ?>
        </div>
    </div>

<script src=" <?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/admin/js/bootstrap.bundle.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/admin/js/datatables.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/admin/js/moment.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/admin/js/fullcalendar.min.js')); ?>"></script>
<script src=" <?php echo e(asset('assets/admin/js/bootadmin.min.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\lightoption\core\resources\views/admin/master.blade.php ENDPATH**/ ?>