<?php $__env->startSection('title', 'Announcement category'); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-fluid">
        <h2 class="mb-4">Announcement Category</h2>
        <div class="row ">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-white font-weight-bold">
                        Category list
                        <a href="<?php echo e(route('admin.blogCategory.create')); ?>"
                           class="btn btn-primary btn-md float-right customs_btn" data-toggle="modal"
                           data-target="#create">
                            <i class="fa fa-plus"></i> ADD NEW
                        </a>
                    </div>
                    <div class="card-body ">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $blogCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($blogCategory->name); ?></td>

                                    <td>
                                        <?php if($blogCategory->status==1): ?>
                                            <button class="btn btn-success btn-sm">Active</button>
                                        <?php else: ?>
                                            <button class="btn btn-danger btn-sm">Inactive</button>
                                        <?php endif; ?>
                                    </td>

                                    <td class=" actions">
                                        <a href="" class="btn btn-info btn-sm btn-square"
                                           data-name="<?php echo e($blogCategory->name); ?>"
                                           data-status="<?php echo e($blogCategory->status); ?>"
                                           data-id="<?php echo e($blogCategory->id); ?>"
                                           data-toggle="modal" data-target="#categoryUpdate"
                                        >Edit</a>

                                        <a href="" class="btn btn-danger btn-sm btn-square" data-id="<?php echo e($blogCategory->id); ?>"
                                           data-toggle="modal" data-target="#CategoryDelete">Delete</a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>



    <!-- delete service Alert Modal -->
    <div class="modal modal-danger fade" id="CategoryDelete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center">Confirmation Message</h4>
                </div>
                <form action="<?php echo e(!empty($blogCategory->id) ? route('admin.blogCategory.destroy','delete') : '#'); ?>"
                      method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <div class="modal-body">
                        <input class="form-control form-control-lg mb-3" type="hidden" name="id" id="id">
                        <h4 class="text-center">Delete all Announcement, if you delete this ?</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Yes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Create category Modal -->
    <div class="modal modal-danger fade" id="create" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center" id="myModalLabel">Create Announcement</h4>
                </div>
                <form action="<?php echo e(route('admin.blogCategory.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="col-md-12 ">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Announcement Name</strong></label>
                                <input class="form-control form-control-lg mb-3" type="text" name="name" id="name"
                                       value="" required>
                            </div>
                        </div>

                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Announcement Status</strong></label>
                                <select class="form-control" id="" name="status" required>
                                    <option selected value="">Category</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit category Modal -->
    <div class="modal modal-danger fade" id="categoryUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center" id="myModalLabel">Edit</h4>
                </div>
                <form action="<?php echo e(route('admin.blogCategory.update','update')); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>


                    <div class="modal-body">
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>name</strong></label>
                                <input class="form-control form-control-lg mb-3" type="text" name="name"
                                       id="name" required>
                            </div>
                        </div>
                        <input class="form-control form-control-lg mb-3" type="hidden" name="id" id="id">
                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Status</strong></label>
                                <select class="form-control" id="status" name="status" required>
                                    <option selected value="">Category</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



<?php $__env->startSection('scripts'); ?>
    
    <script>
        $('#categoryUpdate').on('show.bs.modal', function (event) {

            var button = $(event.relatedTarget)

            var name = button.data('name')
            var status = button.data('status')
            var id = button.data('id')


            var modal = $(this)

            modal.find('.modal-body #name').val(name);
            modal.find('.modal-body #status').val(status);
            modal.find('.modal-body #id').val(id);

            modal.find('select[name=category_status]').val(status);

        })
    </script>

    
    <script>
        $('#CategoryDelete').on('show.bs.modal', function (event) {

            var button = $(event.relatedTarget)
            var id = button.data('id')
            var modal = $(this)
            modal.find('.modal-body #id').val(id);
        })
    </script>
<?php $__env->stopSection(); ?>
    
    <script>
        $('#blog li:nth-child(1)').addClass('active');
        $('#blog').addClass('show');
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lightoption\core\resources\views/admin/frontendsetting/blogCategory.blade.php ENDPATH**/ ?>