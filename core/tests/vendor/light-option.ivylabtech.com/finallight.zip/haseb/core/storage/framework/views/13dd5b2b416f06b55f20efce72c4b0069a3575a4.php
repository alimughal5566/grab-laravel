<?php $__env->startSection('title',$gs->websiteTitle.' | our events'); ?>

<?php $__env->startSection('content'); ?>
    <!--Start Page Content-->
    <section class="page-content fix">
        <!--Start Page Title-->
        <div class="page-title bg-cover position-relative"
             style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/page-bg.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-title-content text-center">
                            <h2 class="text-upper"><?php echo app('translator')->getFromJson('Our Events'); ?></h2>
                            <ol class="breadcrumb">
                                <li>
                                    <a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->getFromJson('Home'); ?></a>
                                </li>
                                <li class="active"><?php echo app('translator')->getFromJson('Events'); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Page Title-->

        <!--Start Events Wrap-->
        <div class="events-wrap default-padding">
            <!--Start Container-->
            <div class="container">
                <!--Start Heading-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-heading text-center">
                            <h3 class="font-2 color-main"><?php echo e(!empty($frontEndSetting->eventTitle1) ? __($frontEndSetting->eventTitle1) : ''); ?></h3>
                            <h2><?php echo e(!empty($frontEndSetting->eventTitle2) ?  __($frontEndSetting->eventTitle2) : ''); ?></h2>
                        </div>
                    </div>
                </div>
                <!--End Heading-->

                <!--Start Row-->
                <div class="row">

                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Start Event Single-->
                        <div class="col-md-6">
                            <div class="event-single position-relative">
                                <img src="<?php echo e(asset('assets/user/images/events/'.$event->event_image)); ?>" class="img-responsive" alt="Image">
                                <div class="event-details">

                                    <a href="<?php echo e(route('user.EventDetails',$event->event_slug)); ?>">
                                        <h2><?php echo e($event->event_title); ?></h2>
                                    </a>
                                    <p><span><i class="icofont icofont-calendar"></i> <?php echo e($event->event_date); ?></span> <span><i
                                                    class="icofont icofont-clock-time"></i> <?php echo e($event->event_duration); ?></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <!--End Event Single-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
                <!--End Row-->

                <!--Start Pagination Row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="post-pagination text-center">
                            <ul class="pagination m-0">
                                <?php echo e($events->links()); ?>

                            </ul>
                        </div>
                    </div>
                </div>
                <!--End Pagination Row-->

            </div>
            <!--End Container-->
        </div>
        <!--End Events Wrap-->
    </section>
    <!--End Page Content-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\haseb\core\resources\views/user/pages/events.blade.php ENDPATH**/ ?>