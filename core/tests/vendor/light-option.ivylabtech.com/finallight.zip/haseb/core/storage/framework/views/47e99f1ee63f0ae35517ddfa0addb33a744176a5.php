<?php $__env->startSection('title', $gs->websiteTitle); ?>

<?php $__env->startSection('content'); ?>
    <!--Start Banner Area-->
    <section class="banner-area bg-cover height-full position-relative"
             style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/banner.png')); ?>);">
        <div class="overlay"></div>
        <!--Start Banner Content-->
        <div class="caption-content display-table">
            <div class="table-cell position-relative">
                <h1 class="font-2 animated fadeInDown"><?php echo e(!empty($frontEndSetting->banner_text1) ? __($frontEndSetting->banner_text1) : ''); ?></h1>

                <h2 class="text-upper animated fadeInDown">
                    
                    <span class="b-text"><?php echo e(preg_replace('/\W\w+\s*(\W*)$/', '$1', __($frontEndSetting->banner_text2))); ?></span>
                    <?php
                        $pieces = explode(' ', $frontEndSetting->banner_text2);
                        $last_word = array_pop($pieces);
                        echo $last_word.'<br>';
                    ?>
                </h2>

                <h3 class="animated fadeInUp"><?php echo e(!empty($frontEndSetting->banner_text3) ? __($frontEndSetting->banner_text3) : ''); ?></h3>
                <div class="default-btn large animated fadeInUp">
                    <a href="<?php echo e(route('user.reservation')); ?>"><?php echo app('translator')->getFromJson('Book Now'); ?></a>
                </div>
            </div>
        </div>
        <!--End Banner Content-->
    </section>
    <!--End Banner Area-->

    <!--Start About Area-->
    <div class="about-area">
        <!--Start Container-->
        <div class="container">
            <!--Start Row-->
            <div class="row">
                <!--Start About Image-->
                <div class="col-md-6">
                    <div class="about-img fix">
                        <img src="<?php echo e(asset('assets/user/images/frontEnd/about_image.jpg')); ?>" class="img-responsive"
                             alt="Image">
                    </div>
                </div>
                <!--End About Image-->
                <!--Start About Content-->
                <div class="col-md-6">
                    <div class="about-content">
                        <h3 class="font-2 color-main m-0"><?php echo e(!empty($aboutSetting->about_title1) ? __($aboutSetting->about_title1) : ''); ?></h3>

                        <h2 class="text-upper"><?php echo e(!empty($aboutSetting->about_title2) ? __($aboutSetting->about_title2) : ''); ?></h2>

                        <p><?php echo e(!empty($aboutSetting->about_text) ?  __($aboutSetting->about_text) : ''); ?></p>
                        <div class="default-btn">
                            <a href="<?php echo e(route('user.about')); ?>"><?php echo app('translator')->getFromJson('Read More'); ?></a>
                        </div>
                    </div>
                </div>
                <!--End About Content-->
            </div>
            <!--End Row-->
        </div>
        <!--End Container-->
    </div>
    <!--End About Area-->

    <!--Start Event Area-->
    <section class="event-area default-padding">
        <!--Start Container-->
        <div class="container">
            <!--Start Section Heading-->
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-heading text-center">
                        <h3 class="font-2 color-main"><?php echo e(!empty($frontEndSetting->eventTitle1) ?  __($frontEndSetting->eventTitle1) : ''); ?></h3>
                        <h2 class="text-upper"><?php echo e(!empty($frontEndSetting->eventTitle2) ?  __($frontEndSetting->eventTitle2) : ''); ?></h2>
                    </div>
                </div>
            </div>
            <!--End Section Heading-->

            <!--Start Row-->
            <div class="row">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--Start Event Single-->
                    <div class="col-md-6">
                        <div class="event-single position-relative">
                            <img src="<?php echo e(asset('assets/user/images/events/'.$event->event_image)); ?>"
                                 class="img-responsive" alt="Image">
                            <div class="event-details">
                                <a href="<?php echo e(route('user.EventDetails',$event->event_slug)); ?>">
                                    <h2><?php echo e(__($event->event_title)); ?></h2>
                                </a>
                                <p><span><i class="icofont icofont-calendar"></i> <?php echo e($event->event_date); ?></span> <span><i
                                                class="icofont icofont-clock-time"></i> <?php echo e($event->event_duration); ?></span>
                                </p>
                            </div>
                        </div>
                    </div>
                    <!--End Event Single-->
                    <?php if($loop->iteration==2): ?>
                        <?php break; ?>;
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!--End Row-->

            <div class="default-btn text-center">
                <a href="<?php echo e(route('user.event')); ?>"><?php echo app('translator')->getFromJson('More Event'); ?></a>
            </div>
        </div>
        <!--End Container-->
    </section>
    <!--End Event Area-->

    <!--Start Gallery Area-->
    <section class="gallery-area bg-gray default-padding">
        <!--Start Container-->
        <div class="container">
            <!--Start Section Heading-->
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-heading text-center">
                        <h3 class="font-2 color-main"><?php echo e(!empty($frontEndSetting->featureTitle1) ? __($frontEndSetting->featureTitle1) : ''); ?></h3>
                        <h2 class="text-upper"><?php echo e(!empty($frontEndSetting->featureTitle2) ? __($frontEndSetting->featureTitle2) : ''); ?></h2>
                    </div>
                </div>
            </div>
            <!--End Section Heading-->

            <!--Start Gallery List-->
            <div class="gallery-list">
                <!--Start Row-->
                <div class="row">
                <?php $__currentLoopData = $foodItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Start Post Single-->
                        <div class="col-md-4">
                            <div class="blog-post-single fix" style="box-shadow: 0 0 10px #bcc6d0;">
                                <div class="post-media lfood">
                                    <a href="<?php echo e(route('user.foodDetails',$foodItem->id)); ?>">

                                        <?php $__currentLoopData = explode(',', $foodItem->food_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <img src="<?php echo e(asset('assets/user/images/foods/'.$f_image)); ?>"
                                                 class="img-responsive" alt="Image">

                                            <?php if($loop->iteration==1): ?>
                                                <?php break; ?>;
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </a>
                                </div>
                                <div class="blog-details">
                                    <div class="post-meta">
                                        <p>
                                            <a href=""><i class="icofont icofont-clock-time"></i> <?php echo e($foodItem->created_at->format('M d, Y')); ?></a>
                                        </p>
                                        <h2 class="m-0"><a href="<?php echo e(route('user.foodDetails',$foodItem->id)); ?>"><?php echo e(__($foodItem->food_name)); ?></a></h2>

                                    </div>
                                    <div class="post-content">
                                        <p>
                                            <?php echo e(\Illuminate\Support\Str::words(__($foodItem->food_description), 12,'....')); ?>

                                        </p>
                                        <div class="row">
                                            <div class="col-md-6" style="margin-top: 50px;">
                                                <b>Price : </b> <span class="base-color"><?php echo e($gs->currencySymbol); ?> <?php echo e($foodItem->food_price); ?></span>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="default-btn">
                                                    <a href="<?php echo e(route('user.foodDetails',$foodItem->id)); ?>" style="color: #fff;">View
                                                        Details</a>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Post Single-->
                        <?php if($loop->iteration==6): ?>
                            <?php break; ?>;
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!--End Row-->
            </div>
            <!--End Gallery List-->

            <div class="default-btn text-center">
                <a href="<?php echo e(route('user.foods')); ?>"><?php echo app('translator')->getFromJson('See More'); ?></a>
            </div>

        </div>
        <!--End Container-->
    </section>
    <!--End Gallery Area-->



    <!--Start Testimonial Area-->
    <section class="testimonial-area bg-cover position-relative"
             style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/banner.png')); ?>);">
        <div class="overlay"></div>

        <!--Start Container-->
        <div class="container">
            <!--Start Row-->
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <!--Start Testimonial Carousel-->
                    <div class="testi-carousel owl-carousel">

                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--Start Testimonial Single-->
                            <div class="testi-single">
                                <div class="client-info text-center">
                                    <img src="<?php echo e(asset('assets/user/images/testimonial/'.$testimonial->profile_photo)); ?>"
                                         class="img-responsive" alt="Image">
                                    <h4><?php echo e($testimonial->name); ?></h4>
                                </div>
                                <div class="client-comment text-center">
                                    <p><?php echo e(__($testimonial->message)); ?></p>
                                    <span><i class="icofont icofont-star"></i><i class="icofont icofont-star"></i><i
                                                class="icofont icofont-star"></i><i class="icofont icofont-star"></i><i
                                                class="icofont icofont-star"></i></span>
                                </div>
                            </div>
                            <!--End Testimonial Single-->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <!--End Testimonial Carousel-->
            </div>
            <!--End Row-->
        </div>
        <!--End Container-->

    </section>
    <!--End Testimonial Area-->

    <!--Start Chef Area-->
    <section class="chef-area default-padding">
        <!--Start Container-->
        <div class="container">
            <!--Start Section Heading-->
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-heading text-center">
                        <h3 class="font-2 color-main"><?php echo e(!empty($frontEndSetting->chefTitle1) ?  __($frontEndSetting->chefTitle1) : ''); ?></h3>
                        <h2 class="text-upper"><?php echo e(!empty($frontEndSetting->chefTitle2) ?  __($frontEndSetting->chefTitle2) : ''); ?></h2>
                    </div>
                </div>
            </div>
            <!--End Section Heading-->

            <!--Start Row-->
            <div class="row">

            <?php $__currentLoopData = $chefs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chef): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--Start Chef Single-->
                    <div class="col-md-3 col-sm-6">
                        <div class="chef-single text-center position-relative">
                            <img src="<?php echo e(asset('assets/user/images/chefs/'.$chef->profile_photo)); ?>"
                                 class="img-responsive" alt="Image">
                            <div class="chef-social">
                                <ul>
                                    <li><a href="<?php echo e($chef->facebook); ?>" target="_blank"><i
                                                    class="icofont icofont-social-facebook"></i></a></li>
                                    <li><a href="<?php echo e($chef->twitter); ?>" target="_blank"><i
                                                    class="icofont icofont-social-twitter"></i></a></li>
                                    <li><a href="<?php echo e($chef->pinterest); ?>" target="_blank"><i
                                                    class="icofont icofont-social-pinterest"></i></a></li>
                                    <li><a href="<?php echo e($chef->linkedin); ?>" target="_blank"><i
                                                    class="icofont icofont-brand-linkedin"></i></a></li>
                                </ul>
                            </div>
                            <div class="chef-info">
                                <h4><?php echo e($chef->name); ?></h4>
                                <p><?php echo e($chef->designation); ?></p>
                            </div>
                        </div>
                    </div>
                    <!--End Chef Single-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <!--End Row-->
        </div>
        <!--End Container-->
    </section>
    <!--End Chef Area-->


    <!--Start Latest Blog-->
    <section class="latest-blog-area  default-padding">
        <!--Start Container-->
        <div class="container">
            <!--Start Section Heading-->
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-heading text-center">
                        <h3 class="font-2 color-main"><?php echo e(!empty($frontEndSetting->newsTitle1) ?  __($frontEndSetting->newsTitle1) : ''); ?></h3>
                        <h2 class="text-upper"><?php echo e(!empty($frontEndSetting->newsTitle2) ?  __($frontEndSetting->newsTitle2) : ''); ?></h2>
                    </div>
                </div>
            </div>
            <!--End Section Heading-->

            <!--Start Row-->
            <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--Start Post Single-->
                    <div class="col-md-4">
                        <div class="blog-post-single fix">
                            <div class="post-media">
                                <a href="<?php echo e(route('user.blogDetails',$post->blog_slug)); ?>"><img
                                            src="<?php echo e(asset('assets/user/images/posts/'.$post->blog_photo)); ?>"
                                            class="img-responsive"
                                            alt="Image"></a>
                            </div>
                            <div class="blog-details">
                                <div class="post-meta">
                                    <h2 class="m-0"><a
                                                href="<?php echo e(route('user.blogDetails',$post->blog_slug)); ?>"><?php echo e(__($post->blog_title)); ?></a>
                                    </h2>
                                    <p>
                                        <a href=""><i class="icofont icofont-user"></i> Admin</a>
                                        <a href=""><i
                                                    class="icofont icofont-clock-time"></i> <?php echo e($post->created_at->format('M d, Y')); ?>

                                        </a>

                                    </p>
                                </div>
                                <div class="post-content">
                                    <p><?php echo e(str_limit(strip_tags(__($post->blog_content)), $limit = 150, $end = '...')); ?></p>
                                    <a href="<?php echo e(route('user.blogDetails',$post->blog_slug)); ?>"><?php echo app('translator')->getFromJson('Read More'); ?> <i
                                                class="icofont icofont-rounded-double-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Post Single-->
                    <?php if($loop->iteration==3): ?>
                        <?php break; ?>;
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <!--End Row-->

            <div class="default-btn text-center">
                <a href="<?php echo e(route('user.blog')); ?>"><?php echo app('translator')->getFromJson('See All Announcement'); ?></a>
            </div>
        </div>
        <!--End Container-->
    </section>
    <!--End Latest Blog-->

<?php $__env->stopSection(); ?>





<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lightoption\core\resources\views/user/pages/index.blade.php ENDPATH**/ ?>