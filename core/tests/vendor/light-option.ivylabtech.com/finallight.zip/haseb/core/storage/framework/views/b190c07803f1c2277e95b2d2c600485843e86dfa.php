<!DOCTYPE html>
<!--[if lt IE 7 ]>
<html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]>
<html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]>
<html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="zxx">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!--Favicon-->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/user/images/frontEnd/icon.png')); ?>"/>
    <!--Bootstrap CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/bootstrap.css')); ?>">
    <!--Owl Carousel CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/owl.carousel.min.css')); ?>">
    <!--Magnific PopUp CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/magnific-popup.css')); ?>">
    <!--Icofont CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/icofont.css')); ?>">
    <!--Font Awesome CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/fontawesome-all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/font-awesome.min.css')); ?>">
    <!--Animate CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/animate.css')); ?>">
    <!--Bootsnav CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/bootsnav.css')); ?>">
    <!--Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/style.css')); ?>">
    <!--Responsive CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/responsive.css')); ?>">
    <!--Color Switcher-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/color-switcher.css')); ?>">

    <!--Modanizr JS-->
    <script src="<?php echo e(asset('assets/user/js/modernizr.custom.js')); ?>"></script>
    <!--[if IE]>
    <!--<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>-->
    <![endif]-->

    <!-- customs scc -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/user/css/customs.css')); ?>">

    
    <script src="<?php echo e(asset('assets/user/js/jquery-2.1.1.min.js')); ?>"></script>
    <link href="<?php echo e(asset('assets/user/css/toastr.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(asset('assets/user/js/toastr.js')); ?>"></script>

    
    <link href="<?php echo e(url('/')); ?>/assets/user/css/color.php?color=<?php echo e($gs->colorCode); ?>" rel="stylesheet">

</head>


<body>
<!--Start Preloader-->
<div class="site-preloader">
    <div class="spinner">
        <div class="double-bounce1"></div>
        <div class="double-bounce2"></div>
    </div>
</div>
<!--End Preloader-->



<!--Start Body Wrap-->
<div id="body-wrap">

    <!--Start Header-->
        <?php echo $__env->make('user.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--End Header-->

        <?php echo $__env->yieldContent('content'); ?>


    <!--Start Footer-->
    <footer class="footer">
        <div class="footer-top text-center">
            <div class="footer-logo">
                <img src="<?php echo e(asset('assets/user/images/frontEnd/logo.png')); ?>" class="img-responsive footer-logo-main" alt="Image">
            </div>
            <div class="footer-social">
                <ul>
                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e($social->link); ?>"><i class="<?php echo e($social->icon); ?>"></i></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="footer-bottom text-center">
            <p>&copy; <?php echo e($frontEndSetting->footerText); ?></p>
        </div>

        <!--Start Click To Top-->
        <div class="totop">
            <a href="#top"><i class="icofont icofont-simple-up"></i></a>
        </div>
        <!--End Click To Top-->
    </footer>
    <!--End Footer-->
</div>
<!--End Body Wrap-->

<!--jQuery JS-->
<script src="<?php echo e(asset('assets/user/js/jquery.min.js')); ?>"></script>

<!--Counter JS-->
<script src="<?php echo e(asset('assets/user/js/waypoints.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/jquery.counterup.min.js')); ?>"></script>
<!--Bootstrap JS-->
<script src="<?php echo e(asset('assets/user/js/bootstrap.min.js')); ?>"></script>
<!--Magnic PopUp JS-->
<script src="<?php echo e(asset('assets/user/js/magnific-popup.min.js')); ?>"></script>
<!--Isotope JS-->
<script src="<?php echo e(asset('assets/user/js/isotope.min.js')); ?>"></script>
<!--Image Loded JS-->
<script src="<?php echo e(asset('assets/user/js/images-loded.min.js')); ?>"></script>
<!--Scrolly JS-->
<script src="<?php echo e(asset('assets/user/js/jquery.scrolly.js')); ?>"></script>
<!--Ripple JS-->
<script src="<?php echo e(asset('assets/user/js/jquery.ripples-min.js')); ?>"></script>
<!--Owl Carousel JS-->
<script src="<?php echo e(asset('assets/user/js/owl.carousel.min.js')); ?>"></script>
<!--Bootsnav JS-->
<script src="<?php echo e(asset('assets/user/js/bootsnav.js')); ?>"></script>
<!--Main JS-->
<script src="<?php echo e(asset('assets/user/js/custom.js')); ?>"></script>


<script>
    <?php if(Session()->has('success')): ?>

toastr.success("<?php echo e(Session('success')); ?>")
    <?php endif; ?>

    <?php if(Session()->has('warning')): ?>

toastr.warning("<?php echo e(Session('warning')); ?>")
    <?php endif; ?>

  <?php if(Session()->has('errors')): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
toastr.error("<?php echo e($error); ?>")
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script>


<script>
    $(document).on('change', '#langSel', function () {
        var code = $(this).val();
        window.location.href = "<?php echo e(url('/')); ?>/change-lang/"+code ;
    });
</script>


<script>
    $(document).on('change', '.alice', function () {
        
        var qty = parseInt($(this).val());
        var price=parseInt($('#prce').html());
        var tots=qty * price;
        //alert(tots);
        $('#tosps').val(tots);
       
    });
</script>

<?php echo $__env->yieldContent('scripts'); ?>



</body>

</html>
<?php /**PATH E:\xamp\htdocs\haseb\core\resources\views/user/master.blade.php ENDPATH**/ ?>