<?php $__env->startSection('title',$gs->websiteTitle.' | Announcement'); ?>

<?php $__env->startSection('content'); ?>

    <!--Start Page Content-->
    <section class="page-content fix">
        <!--Start Page Title-->
        <div class="page-title bg-cover position-relative"
             style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/page-bg.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-title-content text-center">
                            <h2 class="text-upper"><?php echo app('translator')->getFromJson('Announcement'); ?></h2>
                            <ol class="breadcrumb">
                                <li>
                                    <a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->getFromJson('Home'); ?></a>
                                </li>
                                <li class="active"><?php echo app('translator')->getFromJson('Announcement'); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Page Title-->

        <!--Start Blog Wrap-->
        <div class="blog-wrap">
            <!--Start Container-->
            <div class="container">
                <!--Start Post Row-->
                <div class="row">

                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Start Post Single-->
                        <div class="col-md-4 col-sm-6">
                            <div class="blog-post-single">
                                <div class="post-media">
                                    <a href="<?php echo e(route('user.blogDetails',$blog->blog_slug)); ?>">
                                        <img src="<?php echo e(asset('assets/user/images/posts/'.$blog->blog_photo)); ?>"
                                                                    class="img-responsive" alt="Image">
                                    </a>
                                </div>
                                <div class="blog-details">
                                    <div class="post-meta">
                                        <h2 class="m-0">
                                            <a href="<?php echo e(route('user.blogDetails',$blog->blog_slug)); ?>"><?php echo e(__($blog->blog_title)); ?></a>
                                        </h2>
                                        <p>
                                            <a href=""><i class="icofont icofont-user"></i> Admin</a>
                                            <a href=""><i
                                                        class="icofont icofont-clock-time"></i> <?php echo e($blog->created_at->format('M d, Y')); ?>

                                            </a>
                                        </p>
                                    </div>
                                    <div class="post-content">
                                        <p><?php echo e(Str::words(__($blog->blog_content),20)); ?></p>

                                        <a href="<?php echo e(route('user.blogDetails',$blog->blog_slug)); ?>"><?php echo app('translator')->getFromJson('Read More'); ?> <i
                                                    class="icofont icofont-rounded-double-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Post Single-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!--End Post Row-->

                <!--Start Pagination Row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="post-pagination text-center">
                            <ul class="pagination m-0">
                                <?php echo e($blogs->links()); ?>

                            </ul>
                        </div>
                    </div>
                </div>
                <!--End Pagination Row-->
            </div>
            <!--End Container-->
        </div>
        <!--End Blog Wrap-->


    </section>
    <!--End Page Content-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haseb\core\resources\views/user/pages/blog/blog.blade.php ENDPATH**/ ?>