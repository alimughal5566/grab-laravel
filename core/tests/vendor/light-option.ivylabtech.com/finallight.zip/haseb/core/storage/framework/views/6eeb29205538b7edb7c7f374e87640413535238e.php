<?php $__env->startSection('title', 'Admin | Create - Add-Ons'); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <form action="<?php echo e(url('admin/update_assignedaddon',['id' => $id])); ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="_method" value="PUT">
            <?php echo csrf_field(); ?>
            <h2 class="mb-4">
                Assign Add-Ons
            </h2>

            <div class="row mb-4">

                <div class="col-md-12 mt-4">
                    <div class="card">
                        <div class="card-header bg-white font-weight-bold">
                            Assign Add-Ons
                        </div>
                        <div class="card-body ">
                            <div class="row">

                                <div class="col-md-6 mb-4">
                                    <div class="form-group">
                                        <label for="header_subtitle"><strong>Food Items </strong></label>
                                        <select class="form-control" name="fooditem_id" required>
                                            <option selected value="">Please select food item</option>
                                            <?php $__currentLoopData = $fooditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fooditem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($fooditem->id); ?>" <?php if($assignedaddon->fooditem_id==$fooditem->id): ?> selected <?php endif; ?>><?php echo e($fooditem->food_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-4">
                                    <div class="form-group">
                                        <label for="header_subtitle"><strong>Add-ons </strong></label>
                                        <select class="form-control" name="addon_id" required>
                                            <option selected value="">Please select add-ons</option>
                                            <?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($addon->id); ?>" <?php if($assignedaddon->addon_id==$addon->id): ?> selected <?php endif; ?>><?php echo e($addon->addon_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-secondary float-right  customs-btn-bd">Assign</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lightoption\core\resources\views/admin/frontendsetting/updateassignedaddons.blade.php ENDPATH**/ ?>