<div class="sidebar sidebar-dark bg-dark" style="background-color: #fff !important;">
    <ul class="list-unstyled">
        <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-home fa-fw"></i> Dashboard</a></li>

        <li>
            <a href="#foods" data-toggle="collapse">
                <i class="fas fa-utensils"></i> Our Foods
            </a>
            <ul id="foods" class="list-unstyled collapse">

                <li><a href="<?php echo e(route('admin.foodCategory.index')); ?>"><i class="fas fa-utensils"></i> Food Category</a></li>
                <li><a href="<?php echo e(route('admin.foods.index')); ?>"><i class="fas fa-utensils"></i> Food List</a></li>
                <li><a href="<?php echo e(route('admin.foodGallery')); ?>"><i class="fas fa-images"></i> Food Gallery</a></li>
                
                <li><a href="<?php echo e(route('admin.manageaddons')); ?>"><i class="fas fa-utensils"></i> Manage Add-ons </a></li>
                <li><a href="<?php echo e(route('admin.foodavailability')); ?>"><i class="fas fa-utensils"></i> Food Availability </a></li>
            </ul>
        </li>

        <li>
            <a href="#plansprogram" data-toggle="collapse">
                <i class="fas fa-calendar-alt"></i> Plans
            </a>
            <ul id="plansprogram" class="list-unstyled collapse">
                <li><a href="<?php echo e(route('admin.plans')); ?>"><i class="fas fa-calendar-alt"></i> Make Plan</a></li>
                <li><a href="<?php echo e(route('admin.plancategories')); ?>"><i class="fas fa-calendar-alt"></i> Plan Category</a></li>
            </ul>
        </li>















    </ul>
</div><?php /**PATH C:\xampp\htdocs\haseb\core\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>