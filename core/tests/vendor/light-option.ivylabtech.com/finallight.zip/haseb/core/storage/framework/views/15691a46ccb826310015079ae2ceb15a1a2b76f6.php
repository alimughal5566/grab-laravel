<?php $__env->startSection('title',$gs->websiteTitle.' | page not found'); ?>

<?php $__env->startSection('content'); ?>

    <!--Start Page Content-->
    <section class="page-content fix">

        <!--Start Page Title-->
        <div class="page-title bg-cover position-relative" style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/page-bg.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-title-content text-center">
                            <h2 class="text-upper">NOT FOUND</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Page Title-->

        <!--Start Notfound Wrap-->
        <div class="notfound-wrap default-padding">
            <!--Start Container-->
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="notfound-content text-center">
                            <h2>404</h2>
                            <h3>Not Found</h3>
                            <p>The Page You Are Looking Is Not Found!</p>
                            <a href="<?php echo e(route('user.home')); ?>">Back To Home</a>
                        </div>
                    </div>
                </div>
            </div>
            <!--End Container-->
        </div>
        <!--End Notfound Wrap-->
    </section>
    <!--End Page Content-->

<?php $__env->stopSection(); ?>





<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\haseb\core\resources\views/user/404.blade.php ENDPATH**/ ?>