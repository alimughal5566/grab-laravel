<?php $__env->startSection('title', 'Admin | About'); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-fluid">
        <form action="<?php echo e(route('admin.aboutSettings')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h2 class="mb-4">
                About Settings
            </h2>
            <div class="row ">
                <div class="col-md-12">
                    <div class="card mb-4">
                        <div class="card-header bg-white font-weight-bold">
                            About Settings
                        </div>
                        <div class="card-body">

                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <label for="header_subtitle"><strong>About Title 1</strong></label>
                                    <input class="form-control form-control-lg mb-3" type="text" name="about_title1"
                                           value="<?php echo e(!empty($aboutSetting->about_title1) ? $aboutSetting->about_title1 : ''); ?>"
                                           required>
                                </div>
                            </div>

                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <label for="header_subtitle"><strong>About Title 2</strong></label>
                                    <input class="form-control form-control-lg mb-3" type="text" name="about_title2"
                                           value="<?php echo e(!empty($aboutSetting->about_title2) ? $aboutSetting->about_title2 : ''); ?>"
                                           required>
                                </div>
                            </div>

                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <label for="header_subtitle"><strong>About Text</strong></label>
                                    <textarea class="form-control form-control-lg" rows="8" name="about_text"
                                              required><?php echo e(!empty($aboutSetting->about_text) ? $aboutSetting->about_text : ''); ?></textarea>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="header_subtitle"><strong>About image</strong></label>
                                        <input class="form-control form-control-lg mb-3" type="file" name="about_image">
                                        <small class="text-danger">(Image will be resized into 800 x 800px)</small>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="col-md-12">
                                        <img style="width: 200px; height:200px;" class="rounded"
                                             src="<?php echo e(asset('assets/user/images/frontEnd/about_image.jpg')); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 mt-4">
                                <button type="submit" class="btn btn-secondary btn-lg btn-block customs-btn-bd">Save
                                    Changes
                                </button>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>

    
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>



<script>
    $('#frontEndSetting li:nth-child(2)').addClass('active');
    $('#frontEndSetting').addClass('show');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haseb\core\resources\views/admin/frontendsetting/about.blade.php ENDPATH**/ ?>