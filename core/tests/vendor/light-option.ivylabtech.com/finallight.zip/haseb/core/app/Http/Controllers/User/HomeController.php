<?php

namespace App\Http\Controllers\User;

use App\AboutSetting;
use App\BlogCategory;
use App\BlogPost;
use App\Contact;
use App\Counter;
use App\Events;
use App\FoodCategory;
use App\FoodGallery;
use App\FoodItems;
use App\GeneralSetting;
use App\Language;
use App\OurChef;
use App\Reservation;
use App\Testimonial;
use App\Order;
use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class HomeController extends Controller
{
    public function __construct()
    {
        view()->share([
            'aboutSetting' => AboutSetting::first(),
            'events' => Events::orderBy('created_at', 'desc')->paginate(6),
            'counter' => Counter::all(),
            'foodCategories' => FoodCategory::all(),
            'foodItems' => FoodItems::orderBy('created_at', 'desc')->paginate(6),
            'foodGallery' => FoodGallery::all(),
            'testimonials' => Testimonial::all(),
            'chefs' => OurChef::all(),
            'posts' => BlogPost::all(),
            'contacts' => Contact::first(),
            'blogs' => BlogPost::orderBy('created_at', 'desc')->paginate(6),
            'blogCategories' => BlogCategory::orderBy('created_at', 'desc')->get(),

        ]);
    }

    //lang change
    public function changeLang($lang)
    {
        $language = Language::where('code', $lang)->first();
        if (!$language) $lang = 'en';
        session()->put('lang', $lang);
        return redirect()->back();
    }


    //home page
    public function index()
    {
        return view('user.pages.index');
    }

    public function MakeReservation(Request $request)
    {
        $reservation = new Reservation();
        $reservation->name = $request->name;
        $reservation->email = $request->email;
        $reservation->phone = $request->phone;
        $reservation->person_quantity = $request->person_quantity;
        $reservation->date = $request->date;
        $reservation->time = $request->time;
        $reservation->message = $request->message;
        $reservation->save();
        //redirect
        Session()->flash('success', 'Message sent !');
        return redirect()->back();

    }

    //about
    public function ShowAbout()
    {
        return view('user.pages.about');
    }

    //reservation
    public function ShowReservation()
    {
        return view('user.pages.reservation');
    }

    //contact
    public function ShowContact()
    {
        return view('user.pages.contact');
    }


      //menu
    public function ShowMenu()
    {
        $result=FoodItems::select('id','food_name','food_price','food_image')->get();   
        return view('user.pages.menu',compact('result'));
    }

     //product detail
    public function ProductDetail($id)
    {
       //$result=FoodItems::find($id);
        $result=DB::select("SELECT food_items.*,food_categories.food_category_name FROM `food_items` JOIN food_categories ON food_categories.id=food_items.food_category_id where food_items.id='$id'");
//dd($result);
       $result2 = DB::table('assignaddons')
       ->where('assignaddons.fooditem_id',$id)
       ->join('addons', 'addons.id', '=', 'assignaddons.addon_id')
       ->select('addons.*')
       ->get();
     
        return view('user.pages.productdetail',compact('result','result2'));
    }

         //product cart
    // public function cart()
    // {
    //     return view('user.pages.cart');
    // }

    public function checkout()
    {
        return view('user.pages.checkout');
    }

     public function login()
    {
        return view('user.pages.login');
    }

     public function account()
    {
        return view('user.pages.account');
    }



    //Contact mail
    public function ContactMail(Request $request)
    {
        try {

            //Send mail to user
            $gs = GeneralSetting::first();

            $to = $gs->receiveEmail;
            $name = ", i am ".$request->name;
            $subject ="Contact mail form user";
            $message = $request->message;

            send_email($to,$name,$subject,$message);

            //redirect
            Session()->flash('success', 'mail sent successful !');
            return redirect()->back();

        }catch(\Exception $exp) {
            Session()->flash('warning', 'mail sent failed !');
            return redirect()->back();
        }
    }

    //Blog Home page
    public function ShowBlog()
    {
        return view('user.pages.blog.blog');
    }

    //Blog details page
    public function BlogDetails($slug)
    {
        $blogpost = BlogPost::where('blog_slug', $slug)->first();

        //update view_count
        $blogpost->view_count = $blogpost->view_count + 1;
        $blogpost->save();

        return view('user.pages.blog.blogDetails', compact('blogpost'));
    }

    //Blog by category
    public function BlogByCategory($slug)
    {
        $categories = BlogCategory::where('name', $slug)->first();

        $blogByCategory = BlogPost::where('blog_category_id', $categories->id)->paginate(6);

        return view('user.pages.blog.categoryWisePost', compact('blogByCategory'));
    }

    //Show events
    public function ShowEvents()
    {
        return view('user.pages.events');
    }

    //Events details
    public function EventDetails($slug)
    {
        $eventDetails = Events::where('event_slug', $slug)->first();

        //update view_count
        $eventDetails->view_count = $eventDetails->view_count + 1;
        $eventDetails->save();

        return view('user.pages.eventDetails', compact('eventDetails'));
    }

    //Show Foods
    public function ShowFood()
    {
        return view('user.pages.foods');
    }

    public function FoodDetails($id)
    {
        $foods = FoodItems::find($id);

        //update view_count
        $foods->view_count = $foods->view_count + 1;
        $foods->save();

        return view('user.pages.foodDetails',compact('foods'));
    }
    
    //food order
    public function FoodOrder(Request $request,$id)
    {
        $order = new Order();
        $foodName = FoodItems::find($id);
        $order->food_id = $foodName->food_name;
        $order->c_name = $request->name;
        $order->c_mail = $request->email;
        $order->c_quantity = $request->quantity;
        $order->c_phone = $request->phone;
        $order->c_address = $request->address;

        $order->save();
        Session()->flash('success', 'Order successful !');
        return redirect()->back();
    }

    //Show Foods
    public function ShowGallery()
    {
        return view('user.pages.gallery');
    }
}
