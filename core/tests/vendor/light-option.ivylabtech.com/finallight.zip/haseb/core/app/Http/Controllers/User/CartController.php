<?php

namespace App\Http\Controllers\User;

use App\AboutSetting;
use App\BlogCategory;
use App\BlogPost;
use App\Contact;
use App\Counter;
use App\Events;
use App\FoodCategory;
use App\FoodGallery;
use App\FoodItems;
use App\GeneralSetting;
use App\Language;
use App\OurChef;
use App\Reservation;
use App\Testimonial;
use App\Order;
use Cart;
use Session;
use DB;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class CartController extends Controller
{

	public function __construct()
    {
        view()->share([
            'aboutSetting' => AboutSetting::first(),
            'events' => Events::orderBy('created_at', 'desc')->paginate(6),
            'counter' => Counter::all(),
            'foodCategories' => FoodCategory::all(),
            'foodItems' => FoodItems::orderBy('created_at', 'desc')->paginate(6),
            'foodGallery' => FoodGallery::all(),
            'testimonials' => Testimonial::all(),
            'chefs' => OurChef::all(),
            'posts' => BlogPost::all(),
            'contacts' => Contact::first(),
            'blogs' => BlogPost::orderBy('created_at', 'desc')->paginate(6),
            'blogCategories' => BlogCategory::orderBy('created_at', 'desc')->get(),

        ]);
    }


	public function addToCart(Request $request)
	{
		$productId=$request->ProductId; 
		$productById=FoodItems::where('id',$productId)->first();

		$d=Cart::add([
			'id'=>$productId,
			'name'=>$productById->food_name,
			'price'=>$productById->food_price,
			'options' => array('image' => $request->image),
			'quantity'=>$request->qty,
		]);

		return redirect('/cart');
	}


		public function cartShow()
		{
			
			$cartProducts=Cart::getContent();

			 return view('user.pages.cart',compact('cartProducts'));
		}

		public function removeCartProduct($id)
		{

			Cart::remove($id);
			return redirect('/cart');
		}

	public function cart()
	{
		// dd(Session::get('cart'));
		if(!Session::has('cart'))
		{
			 return view('user.pages.cart');
		}
		$cart=Session::get('cart');
		// dd($cart);
		return view('user.pages.cart',compact('cart'));
	}

}