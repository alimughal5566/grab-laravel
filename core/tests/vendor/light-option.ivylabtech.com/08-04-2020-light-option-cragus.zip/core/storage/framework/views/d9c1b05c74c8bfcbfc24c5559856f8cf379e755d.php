<?php $__env->startSection('title', 'Admin | Footer'); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <form action="<?php echo e(route('admin.footerSettings')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h2 class="mb-4">
                Footer
            </h2>

            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body ">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="header_subtitle"><strong>Footer Text</strong></label>
                                        <input class="form-control form-control-lg mb-3" type="text" name="footerText"
                                               value="<?php echo e(!empty($frontEndSetting->footerText) ? $frontEndSetting->footerText : ''); ?>">
                                    </div>
                                </div>

                                <div class="col-md-12 mt-4">
                                    <button type="submit" class="btn btn-secondary btn-lg btn-block customs-btn-bd">Save Changes
                                    </button>
                                </div>

                            </div>
                        </div>

                    </div>

                </div>


            </div>

        </form>
    </div>

<?php $__env->startSection('scripts'); ?>
    
    <script>
        $('#frontEndSetting li:nth-child(8)').addClass('active');
        $('#frontEndSetting').addClass('show');
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\haseb\core\resources\views/admin/frontendsetting/footer.blade.php ENDPATH**/ ?>