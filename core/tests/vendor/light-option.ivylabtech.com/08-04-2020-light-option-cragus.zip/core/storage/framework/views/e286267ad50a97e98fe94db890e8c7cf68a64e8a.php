<?php $__env->startSection('title',$gs->websiteTitle.' | Our food'); ?>

<?php $__env->startSection('content'); ?>
    <!--Start Page Content-->
    <section class="page-content fix">
        <!--Start Page Title-->
        <div class="page-title bg-cover position-relative"
             style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/page-bg.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-title-content text-center">
                            <h2 class="text-upper"><?php echo app('translator')->getFromJson('Our All Food'); ?></h2>
                            <ol class="breadcrumb">
                                <li>
                                    <a href="index.html"><?php echo app('translator')->getFromJson('Home'); ?></a>
                                </li>
                                <li class="active"><?php echo app('translator')->getFromJson('Our Food'); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Page Title-->

        <!--Start Latest Blog-->
        <section class="latest-blog-area bg-gray default-padding">
            <!--Start Container-->
            <div class="container">
                <!--Start Section Heading-->
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="section-heading text-center">
                            <h3 class="font-2 color-main"><?php echo e(!empty($frontEndSetting->foodTitle1) ?  __($frontEndSetting->foodTitle1) : ''); ?></h3>
                            <h2 class="text-upper"><?php echo e(!empty($frontEndSetting->foodTitle2) ?  __($frontEndSetting->foodTitle2) : ''); ?></h2>
                        </div>
                    </div>
                </div>
                <!--End Section Heading-->

                <!--Start Row-->
                <div class="row">
                <?php $__currentLoopData = $foodItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Start Post Single-->
                        <div class="col-md-4">
                            <div class="blog-post-single fix" style="box-shadow: 0 0 10px #bcc6d0;">
                                <div class="post-media lfood">
                                    <a href="<?php echo e(route('user.foodDetails',$foodItem->id)); ?>">

                                        <?php $__currentLoopData = explode(',', $foodItem->food_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <img src="<?php echo e(asset('assets/user/images/foods/'.$f_image)); ?>"
                                                 class="img-responsive" alt="Image">

                                            <?php if($loop->iteration==1): ?>
                                                <?php break; ?>;
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </a>
                                </div>
                                <div class="blog-details">
                                    <div class="post-meta">
                                        <p>
                                            <a href=""><i class="icofont icofont-clock-time"></i> <?php echo e($foodItem->created_at->format('M d, Y')); ?></a>
                                        </p>
                                        <h2 class="m-0"><a
                                                    href="<?php echo e(route('user.foodDetails',$foodItem->id)); ?>"><?php echo e(__($foodItem->food_name)); ?></a>
                                        </h2>

                                    </div>
                                    <div class="post-content">
                                        <p>
                                            <?php echo e(\Illuminate\Support\Str::words(__($foodItem->food_description), 12,'....')); ?>

                                        </p>
                                        <div class="row">
                                            <div class="col-md-6" style="margin-top: 20px;">
                                                <b>Price : </b> <span
                                                        class="base-color"><?php echo e($gs->currencySymbol); ?> <?php echo e($foodItem->food_price); ?></span>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="default-btn">
                                                    <a href="<?php echo e(route('user.foodDetails',$foodItem->id)); ?>" style="color: #fff;"><?php echo app('translator')->getFromJson('View
                                                        Details'); ?></a>
                                                </div>
                                            </div>
                                        </div>

                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--End Post Single-->

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!--End Row-->

                <!--Start Post Pagination-->
                <div class="post-pagination text-center">

                    <ul class="pagination m-0">
                        <?php echo e($foodItems->links()); ?>

                    </ul>
                </div>
                <!--End Post Pagination-->
            </div>
            <!--End Container-->
        </section>
        <!--End Latest Blog-->

    <!--End Gallery Wrap-->
    </section>
    <!--End Page Content-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\haseb\core\resources\views/user/pages/foods.blade.php ENDPATH**/ ?>