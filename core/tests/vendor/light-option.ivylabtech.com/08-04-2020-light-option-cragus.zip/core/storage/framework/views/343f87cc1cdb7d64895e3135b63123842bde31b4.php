<div class="sidebar sidebar-dark bg-dark" style="background-color: #fff !important;">
    <ul class="list-unstyled">
        <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-home fa-fw"></i> Dashboard</a></li>

        <li>
            <a href="#foods" data-toggle="collapse">
                <i class="fas fa-utensils"></i> Our Foods
            </a>
            <ul id="foods" class="list-unstyled collapse">

                <li><a href="<?php echo e(route('admin.foodCategory.index')); ?>"><i class="fas fa-utensils"></i> Food Category</a></li>
                <li><a href="<?php echo e(route('admin.foods.index')); ?>"><i class="fas fa-utensils"></i> Food List</a></li>
                <li><a href="<?php echo e(route('admin.foodGallery')); ?>"><i class="fas fa-images"></i> Food Gallery</a></li>
                
                <li><a href="<?php echo e(route('admin.manageaddons')); ?>"><i class="fas fa-utensils"></i> Manage Add-ons </a></li>
                <li><a href="<?php echo e(route('admin.foodavailability')); ?>"><i class="fas fa-utensils"></i> Food Availability </a></li>
            </ul>
        </li>

        <li>
            <a href="#plansprogram" data-toggle="collapse">
                <i class="fas fa-calendar-alt"></i> Plans
            </a>
            <ul id="plansprogram" class="list-unstyled collapse">
                <li><a href="<?php echo e(route('admin.plans')); ?>"><i class="fas fa-calendar-alt"></i> Make Plan</a></li>
                <li><a href="<?php echo e(route('admin.plancategories')); ?>"><i class="fas fa-calendar-alt"></i> Plan Category</a></li>
            </ul>
        </li>

        <li>
            <a href="#orderPage" data-toggle="collapse">
                <i class="fas fa-cart-plus"></i> Food Order
            </a>
            <ul id="orderPage" class="list-unstyled collapse">

                <li><a href="<?php echo e(route('admin.orderList')); ?>"><i class="fab fa-medrt"></i> Order List</a></li>
                


            </ul>
        </li>



         <li>
            <a href="#Events" data-toggle="collapse">
                <i class="fas fa-calendar-alt"></i> Events
            </a>
            <ul id="Events" class="list-unstyled collapse">

                <li><a href="<?php echo e(route('admin.events.index')); ?>"><i class="fa fa-fw fa-list"></i> Event List</a></li>
                <li><a href="<?php echo e(route('admin.events.create')); ?>"><i class="fas fa-plus"></i> New Event</a></li>

            </ul>
        </li> 

         <li>
            <a href="#blog" data-toggle="collapse">
                <i class="fas fa-bullhorn"></i> Announcement
            </a>
            <ul id="blog" class="list-unstyled collapse">
                <li><a href="<?php echo e(route('admin.blogCategory.index')); ?>"><i class="fa fa-fw fa-list"></i>Category</a>
                </li>
                <li><a href="<?php echo e(route('admin.post.index')); ?>"><i class="fa fa-fw fa-list"></i>Announcement</a></li>

            </ul>
        </li> 







    </ul>
</div><?php /**PATH /home2/hasaanmalik/light-option.ivylabtech.com/core/resources/views/admin/includes/sidebar.blade.php ENDPATH**/ ?>