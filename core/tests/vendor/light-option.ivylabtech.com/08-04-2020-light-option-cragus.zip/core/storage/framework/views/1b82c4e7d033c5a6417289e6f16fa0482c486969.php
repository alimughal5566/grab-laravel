<?php $__env->startSection('title',$gs->websiteTitle.' | Plans'); ?>

<?php $__env->startSection('content'); ?>

    <!--Start Page Content-->
    <section class="page-content fix">
        <!--Start Page Title-->
        <div class="page-title bg-cover position-relative"
             style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/page-bg.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-title-content text-center">
                            <h2 class="text-upper">Home</h2>
                            <ol class="breadcrumb">
                                <li>
                                    <a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->getFromJson('Home'); ?></a>
                                </li>
                                <li class="active">Plan</li>
                                <li class="active">Detail</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Page Title-->



        <!--Start Gallery Wrap-->
        <div class="gallery-wrap">
            <!--Start Container-->
            <div class="container">
                <!--Start Heading-->
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-heading text-center">
                            <h3 class="font-2 color-main">Food Plan</h3>
                            <h2><?php echo e($planname); ?></h2>
                        </div>
                    </div>
                </div>
                <!--End Heading-->

                <!--Start Gallery Button Row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="gallery-button text-center">
                            <div class="button-group filter-button-group">
                                <button class="active" data-filter="*">All</button>
                                <button data-filter=".monday">Monday</button>
                                <button data-filter=".thuesday">Thuesday</button>
                                <button data-filter=".wednesday">Wednesday</button>
                                <button data-filter=".thursday">Thursday</button>
                                <button data-filter=".friday">Friday</button>
                                <button data-filter=".saturday">Saturday</button>
                                <button data-filter=".sunday">Sunday</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Gallery Button Row-->

                <!--Start Gallery List-->
                <div class="gallery-list">
                    <!--Start Row-->
                    <div class="row">
                        <?php $__currentLoopData = $plandetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plandetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-4 gallery-grid 
                            <?php if($plandetail->day_id==1): ?>
                            sunday
                            <?php elseif($plandetail->day_id==2): ?>
                            monday
                            <?php elseif($plandetail->day_id==3): ?>
                            thuesday
                            <?php elseif($plandetail->day_id==4): ?>
                            wednesday
                            <?php elseif($plandetail->day_id==5): ?>
                            thursday
                            <?php elseif($plandetail->day_id==6): ?>
                            friday
                            <?php elseif($plandetail->day_id==7): ?>
                            saturday
                            <?php endif; ?>
                            ">
                                <div class="blog-post-single fix">
                                    <div class="post-media">
                                        <a href="#" class="img-responsive" alt="Image">
                                            <img src="<?php echo e(asset('assets/user/images/foods/'.$plandetail->food_image)); ?>" class="img-responsive" alt="Image" style="width: 100%">
                                        </a>
                                    </div>
                                    <div class="blog-details">
                                        <div class="post-meta">
                                            <h2 class="m-0"><a href="#"><?php echo e($plandetail->food_name); ?></a></h2>
                                            <p>
                                                <a href=""><i class="icofont icofont-calendar"></i> 
                                                    <?php if($plandetail->day_id==1): ?>
                                                    sunday
                                                    <?php elseif($plandetail->day_id==2): ?>
                                                    monday
                                                    <?php elseif($plandetail->day_id==3): ?>
                                                    thuesday
                                                    <?php elseif($plandetail->day_id==4): ?>
                                                    wednesday
                                                    <?php elseif($plandetail->day_id==5): ?>
                                                    thursday
                                                    <?php elseif($plandetail->day_id==6): ?>
                                                    friday
                                                    <?php elseif($plandetail->day_id==7): ?>
                                                    saturday
                                                    <?php endif; ?></a>
                                                <a href=""><i class="icofont icofont-clock-time"></i> 
                                                <?php if($plandetail->food_type_id==1): ?>
                                                    BreakFast
                                                <?php elseif($plandetail->food_type_id==2): ?>
                                                    Lunch
                                                <?php elseif($plandetail->food_type_id==3): ?>
                                                    Snacks
                                                <?php elseif($plandetail->food_type_id==4): ?>
                                                    Dinner
                                                <?php endif; ?>
                                                </a>
                                            </p>
                                        </div>
                                        <div class="post-content">
                                            <p><?php echo e(str_limit(strip_tags(__($plandetail->food_description)), $limit = 50, $end = '...')); ?></p>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <!--End Row-->
                </div>
                <!--End Gallery List-->

                <div class="row">
                    <form action="<?php echo e(route('user.orderplan')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                            <input type="hidden" name="plan_id" value="<?php echo e($planid); ?>">
                            <div class="gallery-button text-center">
                                <button type="submit" class="btn btn-success btn-block btn-lg">Order Plan</button>
                            </div>
                        </div>
                        <div class="col-md-4"></div>
                    </form>
                </div>



            </div>
            <!--End Container-->
        </div>
        <!--End Gallery Wrap-->




    </section>
    <!--End Page Content-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final_light\core\resources\views/user/pages/plandetail.blade.php ENDPATH**/ ?>