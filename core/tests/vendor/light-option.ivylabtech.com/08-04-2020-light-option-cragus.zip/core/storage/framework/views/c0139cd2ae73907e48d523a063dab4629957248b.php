<header class="header">
    <div class="main-menu">
        <nav class="navbar navbar-default bootsnav" data-spy="affix" data-offset-top="10">
            <!-- Start Top Search -->
            <div class="top-search">
                <div class="container">
                    <div class="input-group">
                        <span class="input-group-addon"><i class="icofont icofont-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search">
                        <span class="input-group-addon close-search"><i class="icofont icofont-close"></i></span>
                    </div>
                </div>
            </div>
            <!-- End Top Search -->

            <!--Start Container-->
            <div class="container">
                <!-- Start Atribute Navigation -->
            
            
            
            
            
            <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="icofont icofont-navigation-menu"></i>
                    </button>
                    <a class="navbar-brand logo-main" href="<?php echo e(route('user.home')); ?>">
                        <img src="<?php echo e(asset('assets/user/images/custombilal/logo.png')); ?>" class="logo" alt=""
                             style="max-width: 200px; max-height: 50px;">
                    </a>

                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="fadeIn" data-out="fadeOut">
                        <li>
                            <a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->getFromJson('Home'); ?></a>

                        </li>
                        <li><a href="<?php echo e(route('user.about')); ?>"><?php echo app('translator')->getFromJson('About Us'); ?></a></li>
                        <li><a href="<?php echo e(route('user.menu')); ?>"><?php echo app('translator')->getFromJson('Menu'); ?></a></li>
                      <!--   <li><a href="<?php echo e(route('user.reservation')); ?>"><?php echo app('translator')->getFromJson('Reservation'); ?></a></li> -->
                        <li><a href="<?php echo e(route('user.foods')); ?>"><?php echo app('translator')->getFromJson('Our Food'); ?></a></li>
                        <li><a href="<?php echo e(route('user.gallery')); ?>"><?php echo app('translator')->getFromJson('Food Gallery'); ?></a></li>
                        <li><a href="<?php echo e(route('user.event')); ?>"><?php echo app('translator')->getFromJson('Our Events'); ?></a></li>
                        <li><a href="<?php echo e(route('user.blog')); ?>"><?php echo app('translator')->getFromJson('Announcement'); ?></a></li>
                        <li><a href="<?php echo e(route('user.contact')); ?>"><?php echo app('translator')->getFromJson('Contact'); ?></a></li>


                        
                      <!--   <div class="col-md-9">
                            <?php if(session()->has('message')): ?>
                            <p class="alert alert-success"></p>
                            <?php echo e(session()->get('message')); ?>

                            <?php endif; ?>
                        </div> -->
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!--End Container-->
        </nav>
    </div>
    <div class="clearfix"></div>
</header><?php /**PATH C:\xampp\htdocs\haseb\core\resources\views/user/includes/header.blade.php ENDPATH**/ ?>