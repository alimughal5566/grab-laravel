<?php $__env->startSection('title',$gs->websiteTitle.' | Food Gallery'); ?>


<?php $__env->startSection('content'); ?>
<style type="text/css">

</style>


<!------ Include the above in your HEAD tag ---------->


    <!--Start Page Content-->
    <!--Start Page Title-->
        <div class="page-title bg-cover position-relative" style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/page-bg.jpg')); ?>);">
         <!--    <div class="overlay"></div> -->
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-title-content text-center">
                            <h2 class="text-upper"><?php echo app('translator')->getFromJson('Food Gallery'); ?></h2>
                            <ol class="breadcrumb">
                                <li>
                                    <a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->getFromJson('Home'); ?></a>
                                </li>
                                <li class="active"><?php echo app('translator')->getFromJson('Gallery'); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Page Title-->
<section class="main_content_area">
       

<div class="jumbotron text-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Please check your email</strong> for further instructions on how to complete your account setup.</p>
  <hr>
  <p>
    Having trouble? <a href="">Contact us</a>
  </p>
 <!--  <p class="lead">
    <a class="btn btn-primary btn-sm" href="https://bootstrapcreative.com/" role="button">Continue to homepage</a>
  </p> -->
</div>


                 
    </section>
      
        
    </section>




        </div>



     

     
    <!--End Page Content-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final_light\core\resources\views/user/pages/thank.blade.php ENDPATH**/ ?>