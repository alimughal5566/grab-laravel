<?php $__env->startSection('title', 'Admin | Food Gallery'); ?>

<?php $__env->startSection('body'); ?>

    <div class="container-fluid">
        <h2 class="mb-4">Our Food Gallery</h2>
        <div class="row ">
            <div class="col-md-12 mb-4">
                <div class="card">
                    <div class="card-header bg-white font-weight-bold">
                        Food Photo list
                        <a href=""
                           class="btn btn-primary btn-md float-right customs_btn" data-toggle="modal"
                           data-target="#foodGallery">
                            <i class="fa fa-plus"></i> ADD NEW
                        </a>
                    </div>
                    <div class="card-body ">
                        <div class="row">
                            <?php $__currentLoopData = $foodGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2 text-center">
                                    <img src="<?php echo e(asset('assets/user/images/foodGallery/'.$gallery->food_image)); ?>" class="img-thumbnail"
                                         width="200" height="200">
                                    <a href="<?php echo e(route('admin.foodGalleryDelete',$gallery->id)); ?>"
                                       class="btn btn-danger btn-sm btn-square mt-2"
                                       onclick="return confirm('Are you sure ?')">Remove</a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- Create food gallery image Modal -->
    <div class="modal modal-danger fade" id="foodGallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center" id="myModalLabel">Create food Gallery Image</h4>
                </div>
                <form action="<?php echo e(route('admin.foodGallery')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">

                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Foods category</strong></label>
                                <select class="form-control" id="" name="food_category_id" required>
                                    <option selected value="">Category</option>
                                    <?php $__currentLoopData = $foodCategoryForItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->food_category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-12 mb-3">
                            <div class="form-group">
                                <label for="header_subtitle"><strong>Portfolio Image</strong></label>
                                <input class="form-control form-control-lg mb-3" type="file" name="food_image" required>
                                <small class="text-danger">(Image will be resized into 800 x 800px)</small>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->startSection('scripts'); ?>

    
    <script>
        $('#foods li:nth-child(3)').addClass('active');
        $('#foods').addClass('show');
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\haseb\core\resources\views/admin/frontendsetting/foodGallery.blade.php ENDPATH**/ ?>