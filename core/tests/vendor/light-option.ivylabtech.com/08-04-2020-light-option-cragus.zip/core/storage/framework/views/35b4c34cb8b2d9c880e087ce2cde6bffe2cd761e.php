<?php $__env->startSection('title',$gs->websiteTitle.' | Food Gallery'); ?>

<?php $__env->startSection('content'); ?>
    <!--Start Page Content-->
    <section class="page-content fix">
        <!--Start Page Title-->
        <div class="page-title bg-cover position-relative" style="background-image: url(<?php echo e(asset('assets/user/images/frontEnd/page-bg.jpg')); ?>);">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-title-content text-center">
                            <h2 class="text-upper"><?php echo app('translator')->getFromJson('Food Gallery'); ?></h2>
                            <ol class="breadcrumb">
                                <li>
                                    <a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->getFromJson('Home'); ?></a>
                                </li>
                                <li class="active"><?php echo app('translator')->getFromJson('Gallery'); ?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Page Title-->

        <!--Start Gallery Wrap-->
        <div class="gallery-wrap">
            <!--Start Container-->
            <div class="container">
                <!--Start Heading-->
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-heading text-center">
                            <h3 class="font-2 color-main"><?php echo e(!empty($frontEndSetting->foodGalleryTitle1) ?  __($frontEndSetting->foodGalleryTitle1) : ''); ?></h3>
                            <h2><?php echo e(!empty($frontEndSetting->foodGalleryTitle2) ?  __($frontEndSetting->foodGalleryTitle2) : ''); ?></h2>
                        </div>
                    </div>
                </div>
                <!--End Heading-->

                <!--Start Gallery Button Row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="gallery-button text-center">
                            <div class="button-group filter-button-group">
                                <button class="active" data-filter="*"><?php echo app('translator')->getFromJson('ALL'); ?></button>
                                <?php $__currentLoopData = $foodCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button data-filter=".<?php echo e($foodCategory->food_category_slug); ?>"><?php echo e(__($foodCategory->food_category_name)); ?></button>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Gallery Button Row-->

                <!--Start Gallery List-->
                <div class="gallery-list">
                    <!--Start Row-->
                    <div class="row">
                    <?php $__currentLoopData = $foodGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <!--Start Gallery Single-->
                            <div class="col-md-4 col-sm-6 gallery-grid <?php echo e($gallery->FoodCategory->food_category_slug); ?>">
                                <div class="gallery-single position-relative fix">
                                    <img src="<?php echo e(asset('assets/user/images/foodGallery/'.$gallery->food_image)); ?>"
                                         class="img-responsive" alt="Image">
                                    <div class="gallery-overlay">
                                        <div class="gallery-inner">
                                            <div class="display-table">
                                                <div class="table-cell text-center">
                                                    <a class="popup-img" href="<?php echo e(asset('assets/user/images/foodGallery/'.$gallery->food_image)); ?>"><i class="icofont icofont-drag1"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--End Gallery Single-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <!--End Row-->
                </div>
                <!--End Gallery List-->

            </div>
            <!--End Container-->
        </div>
        <!--End Gallery Wrap-->
    </section>
    <!--End Page Content-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lightoption\core\resources\views/user/pages/gallery.blade.php ENDPATH**/ ?>