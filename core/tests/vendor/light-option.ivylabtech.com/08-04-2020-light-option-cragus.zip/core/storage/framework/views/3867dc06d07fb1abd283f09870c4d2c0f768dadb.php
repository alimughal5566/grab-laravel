<?php $__env->startSection('title', 'Admin | Manage Add-ons'); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">

        <h2 class="mb-4">
            PLans
        </h2>


        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-white font-weight-bold">
                        All Plans
                        <a href="<?php echo e(route('admin.createplan')); ?>"><button type="button" class="btn btn-secondary float-right customs-btn-bd" style="margin-left: 10px;">
                            New Plan
                        </button></a>
                    </div>
                    <div class="card-body ">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">Sr#</th>
                                <th scope="col">Image</th>
                                <th scope="col">Plan Name</th>
                                <th scope="col">Category</th>
                                
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $foodplan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="col"><?php echo e($loop->iteration); ?></th>
                                <th scope="col"><img src="<?php echo e(asset('assets/user/images/plans/'.$plan->plan_image)); ?>" class="img-thumbnail"
                                         width="100" height="100"></th>
                                <th scope="col"><?php echo e($plan->plan_name); ?></th>
                                <th scope="col">
                                    <?php 
                                    foreach ($plancategory as $key => $pcategory)
                                    {
                                        if($pcategory->id==$plan->category_id){
                                            echo $pcategory->category_name;
                                        }
                                    }
                                    ?>
                                </th>
                                
                                <th scope="col"> 
                                    <a href="<?php echo e(url('admin/addplandays',['id' => $plan->id])); ?>" class="btn btn-success btn-sm btn-square">View Days</a>

                                    <a href="<?php echo e(url('admin/plan_edit',['id' => $plan->id])); ?>" class="btn btn-info btn-sm btn-square">Edit</a>


                                    <a href="" class="btn btn-danger btn-sm btn-square" data-id="<?php echo e($plan->id); ?>" data-toggle="modal" data-target="#foodDelete">Delete</a>
                                </th>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <!-- delete Food Alert Modal -->
    <div class="modal modal-danger fade" id="foodDelete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-center">Confirmation!</h4>
                </div>
                <form action="<?php echo e(url('admin/delete_plan')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input class="form-control form-control-lg mb-3" type="hidden" name="id" id="id">
                        <h4 class="text-center">Are you sure ?</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success">Yes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->startSection('scripts'); ?>

    <script>
        $('#foodDelete').on('show.bs.modal', function (event) {

            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('.modal-body #id').val(id);
        })
    </script>
<?php $__env->stopSection(); ?>


<script>
    $('#plansprogram li:nth-child(1)').addClass('active');
    $('#plansprogram').addClass('show');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\final_light\core\resources\views/admin/frontendsetting/plans.blade.php ENDPATH**/ ?>