@extends('user.master')
@section('title',$gs->websiteTitle.' | Plans')

@section('content')

    <!--Start Page Content-->
    <section class="page-content fix">
        <!--Start Page Title-->
        <div class="page-title bg-cover position-relative"
             style="background-image: url({{asset('assets/user/images/frontEnd/page-bg.jpg')}});">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-title-content text-center">
                            <h2 class="text-upper">Home</h2>
                            <ol class="breadcrumb">
                                <li>
                                    <a href="{{route('user.home')}}">@lang('Home')</a>
                                </li>
                                <li class="active">Plan</li>
                                <li class="active">Detail</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Page Title-->



        <!--Start Gallery Wrap-->
        <div class="gallery-wrap">
            <!--Start Container-->
            <div class="container">
                <!--Start Heading-->
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="page-heading text-center">
                            <h3 class="font-2 color-main">Food Plan</h3>
                            <h2>{{$planname}}</h2>
                        </div>
                    </div>
                </div>
                <!--End Heading-->

                <!--Start Gallery Button Row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="gallery-button text-center">
                            <div class="button-group filter-button-group">
                                <button class="active" data-filter="*">All</button>
                                <button data-filter=".monday">Monday</button>
                                <button data-filter=".thuesday">Thuesday</button>
                                <button data-filter=".wednesday">Wednesday</button>
                                <button data-filter=".thursday">Thursday</button>
                                <button data-filter=".friday">Friday</button>
                                <button data-filter=".saturday">Saturday</button>
                                <button data-filter=".sunday">Sunday</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Gallery Button Row-->

                <!--Start Gallery List-->
                <div class="gallery-list">
                    <!--Start Row-->
                    <div class="row">
                        @foreach($plandetails as $plandetail)

                            <div class="col-md-4 gallery-grid 
                            @if($plandetail->day_id==1)
                            sunday
                            @elseif($plandetail->day_id==2)
                            monday
                            @elseif($plandetail->day_id==3)
                            thuesday
                            @elseif($plandetail->day_id==4)
                            wednesday
                            @elseif($plandetail->day_id==5)
                            thursday
                            @elseif($plandetail->day_id==6)
                            friday
                            @elseif($plandetail->day_id==7)
                            saturday
                            @endif()
                            ">
                                <div class="blog-post-single fix">
                                    <div class="post-media">
                                        <a href="#" class="img-responsive" alt="Image">
                                            <img src="{{asset('assets/user/images/foods/'.$plandetail->food_image)}}" class="img-responsive" alt="Image" style="width: 100%">
                                        </a>
                                    </div>
                                    <div class="blog-details">
                                        <div class="post-meta">
                                            <h2 class="m-0"><a href="#">{{$plandetail->food_name}}</a></h2>
                                            <p>
                                                <a href=""><i class="icofont icofont-calendar"></i> 
                                                    @if($plandetail->day_id==1)
                                                    sunday
                                                    @elseif($plandetail->day_id==2)
                                                    monday
                                                    @elseif($plandetail->day_id==3)
                                                    thuesday
                                                    @elseif($plandetail->day_id==4)
                                                    wednesday
                                                    @elseif($plandetail->day_id==5)
                                                    thursday
                                                    @elseif($plandetail->day_id==6)
                                                    friday
                                                    @elseif($plandetail->day_id==7)
                                                    saturday
                                                    @endif</a>
                                                <a href=""><i class="icofont icofont-clock-time"></i> 
                                                @if($plandetail->food_type_id==1)
                                                    BreakFast
                                                @elseif($plandetail->food_type_id==2)
                                                    Lunch
                                                @elseif($plandetail->food_type_id==3)
                                                    Snacks
                                                @elseif($plandetail->food_type_id==4)
                                                    Dinner
                                                @endif
                                                </a>
                                            </p>
                                        </div>
                                        <div class="post-content">
                                            <p>{{str_limit(strip_tags(__($plandetail->food_description)), $limit = 50, $end = '...')}}</p>
                                            {{-- <a href="#">@lang('Read More') <i
                                                        class="icofont icofont-rounded-double-right"></i></a> --}}
                                        </div>
                                    </div>
                                </div>
                            </div>
                    
                        @endforeach

                    </div>
                    <!--End Row-->
                </div>
                <!--End Gallery List-->

                <div class="row">
                    <form action="{{ route('user.orderplan') }}" method="POST">
                    @csrf
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                            <input type="hidden" name="plan_id" value="{{$planid}}">
                            <div class="gallery-button text-center">
                                <button type="submit" class="btn btn-success btn-block btn-lg">Order Plan</button>
                            </div>
                        </div>
                        <div class="col-md-4"></div>
                    </form>
                </div>



            </div>
            <!--End Container-->
        </div>
        <!--End Gallery Wrap-->




    </section>
    <!--End Page Content-->


@endsection
