<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mealdetail extends Model
{
	
}
